
int a= 3,b=6,c=1;
float d= a/b+c;

